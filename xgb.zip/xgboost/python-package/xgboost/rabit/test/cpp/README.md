Unittests for Rabit
