Python API of Rabit
===================
This page contains document of python API of rabit.

```eval_rst
.. toctree::

.. automodule:: rabit
    :members:
    :show-inheritance:
```
